#!/usr/bin/env python
print('Django manage.py')