SECRET_KEY = 'fake-key'
INSTALLED_APPS = ['django.contrib.admin']